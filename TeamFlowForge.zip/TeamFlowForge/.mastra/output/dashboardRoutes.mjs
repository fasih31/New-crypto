function registerDashboardRoutes(app) {
  app.get("/dashboard", async (c) => {
    const html = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scrum Automation Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .metric-card { transition: all 0.3s ease; }
        .metric-card:hover { transform: translateY(-4px); box-shadow: 0 12px 24px rgba(0,0,0,0.1); }
        .status-indicator { width: 12px; height: 12px; border-radius: 50%; display: inline-block; margin-right: 8px; }
        .status-healthy { background-color: #10b981; }
        .status-warning { background-color: #f59e0b; }
        .status-critical { background-color: #ef4444; }
    </style>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-white shadow-sm border-b border-gray-200">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
                <div class="flex justify-between items-center">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">Scrum Automation Dashboard</h1>
                        <p class="text-sm text-gray-500 mt-1">Real-time monitoring and analytics</p>
                    </div>
                    <div class="flex gap-3">
                        <button onclick="runWorkflow()" 
                                class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                            \u25B6 Run Workflow Now
                        </button>
                        <button onclick="refreshDashboard()" 
                                class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition">
                            \u{1F504} Refresh
                        </button>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <!-- Loading State -->
            <div id="loading" class="text-center py-12">
                <div class="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                <p class="mt-4 text-gray-600">Loading dashboard data...</p>
            </div>

            <!-- Dashboard Content (hidden initially) -->
            <div id="dashboard-content" class="hidden">
                <!-- Overview Metrics -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
                    <div class="metric-card bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                        <div class="text-sm font-medium text-gray-500 mb-2">Active Tasks</div>
                        <div class="text-3xl font-bold text-gray-900" id="metric-active-tasks">-</div>
                    </div>
                    <div class="metric-card bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                        <div class="text-sm font-medium text-gray-500 mb-2">Missing Fields</div>
                        <div class="text-3xl font-bold text-orange-600" id="metric-missing-fields">-</div>
                    </div>
                    <div class="metric-card bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                        <div class="text-sm font-medium text-gray-500 mb-2">Inactive Tasks</div>
                        <div class="text-3xl font-bold text-red-600" id="metric-inactive-tasks">-</div>
                    </div>
                    <div class="metric-card bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                        <div class="text-sm font-medium text-gray-500 mb-2">Recent Reminders</div>
                        <div class="text-3xl font-bold text-blue-600" id="metric-reminders">-</div>
                    </div>
                    <div class="metric-card bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                        <div class="text-sm font-medium text-gray-500 mb-2">Escalations</div>
                        <div class="text-3xl font-bold text-purple-600" id="metric-escalations">-</div>
                    </div>
                </div>

                <!-- Sprint Health -->
                <div class="bg-white rounded-lg shadow-sm p-6 mb-8 border border-gray-200">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">Sprint Health</h2>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                            <div class="flex items-center mb-2">
                                <span id="health-indicator" class="status-indicator status-healthy"></span>
                                <span class="text-sm font-medium text-gray-500">Sprint: <span id="sprint-id">-</span></span>
                            </div>
                            <div class="text-4xl font-bold text-gray-900 mb-1" id="completion-probability">-</div>
                            <div class="text-sm text-gray-500">Completion Probability</div>
                        </div>
                        <div>
                            <div class="text-sm font-medium text-gray-500 mb-2">Days Remaining</div>
                            <div class="text-4xl font-bold text-gray-900" id="days-remaining">-</div>
                        </div>
                        <div>
                            <div class="text-sm font-medium text-gray-500 mb-2">Velocity Projection</div>
                            <div class="text-4xl font-bold text-gray-900" id="velocity-projection">-</div>
                            <div class="text-sm text-gray-500">story points</div>
                        </div>
                    </div>
                    <div class="mt-6 grid grid-cols-3 gap-4">
                        <div class="text-center p-4 bg-red-50 rounded-lg">
                            <div class="text-2xl font-bold text-red-600" id="blocked-tasks">-</div>
                            <div class="text-sm text-gray-600">Blocked Tasks</div>
                        </div>
                        <div class="text-center p-4 bg-yellow-50 rounded-lg">
                            <div class="text-2xl font-bold text-yellow-600" id="stale-tasks">-</div>
                            <div class="text-sm text-gray-600">Stale Tasks</div>
                        </div>
                        <div class="text-center p-4 bg-orange-50 rounded-lg">
                            <div class="text-2xl font-bold text-orange-600" id="risks-count">-</div>
                            <div class="text-sm text-gray-600">Identified Risks</div>
                        </div>
                    </div>
                </div>

                <!-- Analytics Charts -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                    <div class="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Tasks by Priority</h3>
                        <canvas id="priority-chart"></canvas>
                    </div>
                    <div class="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Missing Fields Breakdown</h3>
                        <canvas id="fields-chart"></canvas>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="bg-white rounded-lg shadow-sm p-6 mb-8 border border-gray-200">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">Recent Activity</h2>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead>
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Task</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Assignee</th>
                                </tr>
                            </thead>
                            <tbody id="activity-table" class="divide-y divide-gray-200">
                                <!-- Populated by JavaScript -->
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Workflow History -->
                <div class="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">Workflow Execution History</h2>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead>
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Run ID</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Processed</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Reminders</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Escalations</th>
                                </tr>
                            </thead>
                            <tbody id="workflow-table" class="divide-y divide-gray-200">
                                <!-- Populated by JavaScript -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        let priorityChart, fieldsChart;

        async function loadDashboard() {
            try {
                const response = await fetch('/api/dashboard/metrics');
                const data = await response.json();
                
                updateMetrics(data);
                updateCharts(data);
                updateActivityTable(data.recentActivity);
                updateWorkflowTable(data.workflowHistory);
                
                document.getElementById('loading').classList.add('hidden');
                document.getElementById('dashboard-content').classList.remove('hidden');
            } catch (error) {
                console.error('Error loading dashboard:', error);
                document.getElementById('loading').innerHTML = '<p class="text-red-600">Error loading dashboard. Please try again.</p>';
            }
        }

        function updateMetrics(data) {
            document.getElementById('metric-active-tasks').textContent = data.overview.totalActiveTasks;
            document.getElementById('metric-missing-fields').textContent = data.overview.tasksWithMissingFields;
            document.getElementById('metric-inactive-tasks').textContent = data.overview.inactiveTasks;
            document.getElementById('metric-reminders').textContent = data.overview.recentReminders;
            document.getElementById('metric-escalations').textContent = data.overview.recentEscalations;
            
            document.getElementById('sprint-id').textContent = data.sprintHealth.sprintId;
            document.getElementById('completion-probability').textContent = Math.round(data.sprintHealth.completionProbability) + '%';
            document.getElementById('days-remaining').textContent = data.sprintHealth.daysRemaining;
            document.getElementById('velocity-projection').textContent = Math.round(data.sprintHealth.velocityProjection);
            document.getElementById('blocked-tasks').textContent = data.sprintHealth.blockedTasks;
            document.getElementById('stale-tasks').textContent = data.sprintHealth.staleTasks;
            document.getElementById('risks-count').textContent = data.sprintHealth.risksCount;
            
            const indicator = document.getElementById('health-indicator');
            if (data.sprintHealth.completionProbability >= 80) {
                indicator.className = 'status-indicator status-healthy';
            } else if (data.sprintHealth.completionProbability >= 60) {
                indicator.className = 'status-indicator status-warning';
            } else {
                indicator.className = 'status-indicator status-critical';
            }
        }

        function updateCharts(data) {
            const priorityCtx = document.getElementById('priority-chart').getContext('2d');
            const fieldsCtx = document.getElementById('fields-chart').getContext('2d');
            
            if (priorityChart) priorityChart.destroy();
            if (fieldsChart) fieldsChart.destroy();
            
            priorityChart = new Chart(priorityCtx, {
                type: 'doughnut',
                data: {
                    labels: Object.keys(data.taskAnalytics.byPriority),
                    datasets: [{
                        data: Object.values(data.taskAnalytics.byPriority),
                        backgroundColor: ['#ef4444', '#f59e0b', '#3b82f6', '#10b981']
                    }]
                },
                options: { responsive: true, maintainAspectRatio: true }
            });
            
            fieldsChart = new Chart(fieldsCtx, {
                type: 'bar',
                data: {
                    labels: Object.keys(data.taskAnalytics.missingFieldsBreakdown),
                    datasets: [{
                        label: 'Missing Count',
                        data: Object.values(data.taskAnalytics.missingFieldsBreakdown),
                        backgroundColor: '#f59e0b'
                    }]
                },
                options: { responsive: true, maintainAspectRatio: true, scales: { y: { beginAtZero: true } } }
            });
        }

        function updateActivityTable(activities) {
            const tbody = document.getElementById('activity-table');
            tbody.innerHTML = activities.map(activity => {
                const badge = activity.type === 'escalation' ? 'bg-red-100 text-red-800' : 
                             activity.type === 'field_reminder' ? 'bg-orange-100 text-orange-800' : 
                             'bg-blue-100 text-blue-800';
                return \`
                    <tr>
                        <td class="px-4 py-3 text-sm text-gray-900">\${new Date(activity.timestamp).toLocaleString()}</td>
                        <td class="px-4 py-3 text-sm"><span class="px-2 py-1 rounded-full text-xs \${badge}">\${activity.type}</span></td>
                        <td class="px-4 py-3 text-sm text-gray-900">#\${activity.taskId}: \${activity.taskTitle}</td>
                        <td class="px-4 py-3 text-sm text-gray-600">\${activity.assignee}</td>
                    </tr>
                \`;
            }).join('');
        }

        function updateWorkflowTable(history) {
            const tbody = document.getElementById('workflow-table');
            tbody.innerHTML = history.map(run => \`
                <tr>
                    <td class="px-4 py-3 text-sm font-mono text-gray-900">\${run.runId.substring(0, 8)}...</td>
                    <td class="px-4 py-3 text-sm text-gray-900">\${new Date(run.timestamp).toLocaleString()}</td>
                    <td class="px-4 py-3 text-sm"><span class="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">\${run.status}</span></td>
                    <td class="px-4 py-3 text-sm text-gray-900">\${run.processed}</td>
                    <td class="px-4 py-3 text-sm text-gray-900">\${run.reminders}</td>
                    <td class="px-4 py-3 text-sm text-gray-900">\${run.escalations}</td>
                </tr>
            \`).join('');
        }

        async function runWorkflow() {
            if (confirm('Run the scrum automation workflow now?')) {
                document.getElementById('loading').classList.remove('hidden');
                document.getElementById('dashboard-content').classList.add('hidden');
                
                try {
                    await fetch('/api/dashboard/run-workflow', { method: 'POST' });
                    setTimeout(loadDashboard, 3000);
                } catch (error) {
                    alert('Error running workflow: ' + error.message);
                    loadDashboard();
                }
            }
        }

        function refreshDashboard() {
            document.getElementById('loading').classList.remove('hidden');
            document.getElementById('dashboard-content').classList.add('hidden');
            loadDashboard();
        }

        loadDashboard();
        setInterval(loadDashboard, 30000); // Auto-refresh every 30 seconds
    </script>
</body>
</html>
    `;
    return c.html(html);
  });
  app.get("/api/dashboard/metrics", async (c) => {
    const metrics = {
      overview: {
        totalActiveTasks: 0,
        tasksWithMissingFields: 0,
        inactiveTasks: 0,
        recentReminders: 0,
        recentEscalations: 0
      },
      sprintHealth: {
        sprintId: "Loading...",
        completionProbability: 0,
        velocityProjection: 0,
        blockedTasks: 0,
        staleTasks: 0,
        daysRemaining: 0,
        risksCount: 0
      },
      taskAnalytics: {
        byPriority: {},
        byState: {},
        missingFieldsBreakdown: {}
      },
      recentActivity: [],
      workflowHistory: []
    };
    return c.json(metrics);
  });
  app.post("/api/dashboard/run-workflow", async (c) => {
    const mastra = c.get("mastra");
    const workflow = mastra?.getWorkflow("scrumAutomationWorkflow");
    if (!workflow) {
      return c.json({ error: "Workflow not found" }, 404);
    }
    try {
      const run = await workflow.createRunAsync();
      const result = await run.start({ inputData: {} });
      return c.json({ success: true, runId: run.runId, result });
    } catch (error) {
      return c.json({ error: error.message }, 500);
    }
  });
}

export { registerDashboardRoutes };
//# sourceMappingURL=dashboardRoutes.mjs.map
