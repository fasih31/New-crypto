import { Mastra } from '@mastra/core';
import { MastraError } from '@mastra/core/error';
import { PinoLogger } from '@mastra/loggers';
import { MastraLogger, LogLevel } from '@mastra/core/logger';
import pino from 'pino';
import { MCPServer } from '@mastra/mcp';
import { Inngest, NonRetriableError } from 'inngest';
import { z } from 'zod';
import { PostgresStore } from '@mastra/pg';
import { realtimeMiddleware } from '@inngest/realtime';
import { serve, init } from '@mastra/inngest';
import { createTool } from '@mastra/core/tools';
import { RuntimeContext } from '@mastra/core/di';

const sharedPostgresStorage = new PostgresStore({
  connectionString: process.env.DATABASE_URL || "postgresql://localhost:5432/mastra"
});

const inngest = new Inngest(
  process.env.NODE_ENV === "production" ? {
    id: "replit-agent-workflow",
    name: "Replit Agent Workflow System"
  } : {
    id: "mastra",
    baseUrl: "http://localhost:3000",
    isDev: true,
    middleware: [realtimeMiddleware()]
  }
);

const {
  createWorkflow: originalCreateWorkflow,
  createStep} = init(inngest);
function createWorkflow(params) {
  return originalCreateWorkflow({
    ...params,
    retryConfig: {
      attempts: process.env.NODE_ENV === "production" ? 3 : 0,
      ...params.retryConfig ?? {}
    }
  });
}
const inngestFunctions = [];
function registerCronWorkflow(cronExpression, workflow) {
  const f = inngest.createFunction(
    { id: "cron-trigger" },
    [{ event: "replit/cron.trigger" }, { cron: cronExpression }],
    async ({ event, step }) => {
      const run = await workflow.createRunAsync();
      const result = await run.start({ inputData: {} });
      return result;
    }
  );
  inngestFunctions.push(f);
}
function inngestServe({
  mastra,
  inngest: inngest2
}) {
  let serveHost = void 0;
  if (process.env.NODE_ENV === "production") {
    if (process.env.REPLIT_DOMAINS) {
      serveHost = `https://${process.env.REPLIT_DOMAINS.split(",")[0]}`;
    }
  } else {
    serveHost = "http://localhost:5000";
  }
  return serve({
    mastra,
    inngest: inngest2,
    functions: inngestFunctions,
    registerOptions: { serveHost }
  });
}

const CURRENT_SPRINT = {
  id: "Sprint 24",
  startDate: new Date(Date.now() - 7 * 24 * 60 * 60 * 1e3).toISOString(),
  endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1e3).toISOString(),
  // 7 days left
  totalStoryPoints: 45,
  completedStoryPoints: 18
};
const MOCK_TASKS = [
  {
    id: 1234,
    title: "Implement user authentication",
    assignedTo: {
      displayName: "John Smith",
      email: "john.smith@company.com",
      managerId: "manager1"
    },
    state: "Active",
    priority: "High",
    lastUpdated: new Date(Date.now() - 72 * 60 * 60 * 1e3).toISOString(),
    // 3 days ago
    createdDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1e3).toISOString(),
    url: "https://dev.azure.com/company/project/_workitems/edit/1234",
    storyPoints: 8,
    sprintId: "Sprint 24",
    blockedBy: null,
    tags: ["authentication", "security"],
    description: "Implement OAuth2 authentication for the application",
    acceptanceCriteria: "Users can login with Google and GitHub",
    effort: "Medium",
    reproSteps: null
    // Not applicable for features
  },
  {
    id: 1235,
    title: "Fix login page bug",
    assignedTo: {
      displayName: "Sarah Johnson",
      email: "sarah.johnson@company.com",
      managerId: "manager1"
    },
    state: "Active",
    priority: "Critical",
    lastUpdated: new Date(Date.now() - 96 * 60 * 60 * 1e3).toISOString(),
    // 4 days ago
    createdDate: new Date(Date.now() - 12 * 24 * 60 * 60 * 1e3).toISOString(),
    url: "https://dev.azure.com/company/project/_workitems/edit/1235",
    storyPoints: 3,
    sprintId: "Sprint 24",
    blockedBy: null,
    tags: ["bug", "ui", "critical"],
    description: "",
    // Missing!
    acceptanceCriteria: null,
    effort: null,
    reproSteps: ""
    // Missing for a bug!
  },
  {
    id: 1236,
    title: "Update documentation",
    assignedTo: {
      displayName: "Mike Chen",
      email: "mike.chen@company.com",
      managerId: "manager2"
    },
    state: "Active",
    priority: "Medium",
    lastUpdated: new Date(Date.now() - 12 * 60 * 60 * 1e3).toISOString(),
    // 12 hours ago (recent)
    createdDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1e3).toISOString(),
    url: "https://dev.azure.com/company/project/_workitems/edit/1236",
    storyPoints: 2,
    sprintId: "Sprint 24",
    blockedBy: null,
    tags: ["documentation"],
    description: "Update API documentation for new endpoints",
    acceptanceCriteria: "All endpoints documented with examples",
    effort: "Small",
    reproSteps: null
  },
  {
    id: 1237,
    title: "Database performance optimization",
    assignedTo: {
      displayName: "Emily Davis",
      email: "emily.davis@company.com",
      managerId: "manager2"
    },
    state: "Active",
    priority: "High",
    lastUpdated: new Date(Date.now() - 120 * 60 * 60 * 1e3).toISOString(),
    // 5 days ago
    createdDate: new Date(Date.now() - 15 * 24 * 60 * 60 * 1e3).toISOString(),
    url: "https://dev.azure.com/company/project/_workitems/edit/1237",
    storyPoints: 13,
    sprintId: "Sprint 24",
    blockedBy: null,
    tags: ["performance", "backend"],
    description: "Optimize database queries and add indexes",
    acceptanceCriteria: null,
    // Missing!
    effort: "Large",
    reproSteps: null
  },
  {
    id: 1238,
    title: "Setup CI/CD pipeline",
    assignedTo: {
      displayName: "John Smith",
      email: "john.smith@company.com",
      managerId: "manager1"
    },
    state: "Active",
    priority: "High",
    lastUpdated: new Date(Date.now() - 60 * 60 * 60 * 1e3).toISOString(),
    // 2.5 days ago
    createdDate: new Date(Date.now() - 8 * 24 * 60 * 60 * 1e3).toISOString(),
    url: "https://dev.azure.com/company/project/_workitems/edit/1238",
    storyPoints: 5,
    sprintId: "Sprint 24",
    blockedBy: 1234,
    // Blocked by authentication task
    tags: ["devops", "infrastructure"],
    description: "Setup automated deployment pipeline",
    acceptanceCriteria: "Code deploys automatically on merge to main",
    effort: "Medium",
    reproSteps: null
  }
];
const MOCK_MANAGERS = {
  manager1: {
    displayName: "Alice Manager",
    email: "alice.manager@company.com"
  },
  manager2: {
    displayName: "Bob Director",
    email: "bob.director@company.com"
  }
};
const azureDevOpsTool = createTool({
  id: "azure-devops-fetch-tasks",
  description: "Fetches work items (tasks) from Azure DevOps to monitor activity and identify inactive tasks",
  inputSchema: z.object({
    state: z.string().optional().describe("Filter by task state (e.g., 'Active', 'Resolved')"),
    assignedTo: z.string().optional().describe("Filter by assigned user email")
  }),
  outputSchema: z.object({
    tasks: z.array(z.object({
      id: z.number(),
      title: z.string(),
      assignedTo: z.object({
        displayName: z.string(),
        email: z.string(),
        managerId: z.string()
      }),
      state: z.string(),
      priority: z.string(),
      lastUpdated: z.string(),
      createdDate: z.string(),
      url: z.string(),
      storyPoints: z.number(),
      sprintId: z.string(),
      blockedBy: z.number().nullable(),
      tags: z.array(z.string()),
      description: z.string().nullable(),
      acceptanceCriteria: z.string().nullable(),
      effort: z.string().nullable(),
      reproSteps: z.string().nullable(),
      missingFields: z.array(z.string()),
      manager: z.object({
        displayName: z.string(),
        email: z.string()
      }).optional()
    })),
    totalCount: z.number(),
    sprintContext: z.object({
      id: z.string(),
      startDate: z.string(),
      endDate: z.string(),
      totalStoryPoints: z.number(),
      completedStoryPoints: z.number(),
      daysRemaining: z.number(),
      velocityOnTrack: z.boolean()
    })
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F527} [Azure DevOps Tool] Starting execution", { filters: context });
    logger?.info("\u{1F4DD} [Azure DevOps Tool] Using mock data for development");
    let filteredTasks = [...MOCK_TASKS];
    if (context.state) {
      filteredTasks = filteredTasks.filter((task) => task.state === context.state);
    }
    if (context.assignedTo) {
      filteredTasks = filteredTasks.filter((task) => task.assignedTo.email === context.assignedTo);
    }
    const tasksWithManagers = filteredTasks.map((task) => {
      const missingFields = [];
      const isBug = task.tags.includes("bug");
      if (!task.description || task.description.trim() === "") {
        missingFields.push("Description");
      }
      if (!task.acceptanceCriteria || task.acceptanceCriteria.trim() === "") {
        missingFields.push("Acceptance Criteria");
      }
      if (!task.effort) {
        missingFields.push("Effort");
      }
      if (isBug && (!task.reproSteps || task.reproSteps.trim() === "")) {
        missingFields.push("Repro Steps");
      }
      return {
        ...task,
        missingFields,
        manager: MOCK_MANAGERS[task.assignedTo.managerId]
      };
    });
    const sprintEnd = new Date(CURRENT_SPRINT.endDate);
    const now = /* @__PURE__ */ new Date();
    const daysRemaining = Math.ceil((sprintEnd.getTime() - now.getTime()) / (1e3 * 60 * 60 * 24));
    const sprintContext = {
      ...CURRENT_SPRINT,
      daysRemaining,
      velocityOnTrack: CURRENT_SPRINT.completedStoryPoints >= CURRENT_SPRINT.totalStoryPoints * 0.4
      // At least 40% done midway
    };
    logger?.info("\u2705 [Azure DevOps Tool] Completed successfully", {
      totalCount: tasksWithManagers.length,
      taskIds: tasksWithManagers.map((t) => t.id),
      sprintDaysRemaining: daysRemaining,
      velocityOnTrack: sprintContext.velocityOnTrack
    });
    return {
      tasks: tasksWithManagers,
      totalCount: tasksWithManagers.length,
      sprintContext
    };
  }
});

const outlookEmailTool = createTool({
  id: "outlook-send-email",
  description: "Sends an email via Outlook to notify team members about task updates, reminders, or escalations",
  inputSchema: z.object({
    to: z.string().describe("Recipient email address"),
    subject: z.string().describe("Email subject line"),
    body: z.string().describe("Email body content (can include HTML)"),
    cc: z.string().optional().describe("CC email address (optional)"),
    importance: z.enum(["low", "normal", "high"]).optional().describe("Email importance level")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    messageId: z.string(),
    sentTo: z.string(),
    sentAt: z.string()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F4E7} [Outlook Email Tool] Starting execution", {
      to: context.to,
      subject: context.subject
    });
    logger?.info("\u{1F4DD} [Outlook Email Tool] Using mock implementation for development");
    logger?.info("\u{1F4EC} [Outlook Email Tool] Email details:", {
      to: context.to,
      subject: context.subject,
      bodyPreview: context.body.substring(0, 100) + "...",
      cc: context.cc,
      importance: context.importance || "normal"
    });
    const messageId = `mock-msg-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const sentAt = (/* @__PURE__ */ new Date()).toISOString();
    logger?.info("\u2705 [Outlook Email Tool] Email sent successfully", {
      messageId,
      sentTo: context.to,
      sentAt
    });
    return {
      success: true,
      messageId,
      sentTo: context.to,
      sentAt
    };
  }
});

const teamsMessageTool = createTool({
  id: "teams-send-message",
  description: "Sends a direct message via Microsoft Teams to notify team members about task updates or reminders",
  inputSchema: z.object({
    userEmail: z.string().describe("Email address of the Teams user to message"),
    message: z.string().describe("Message content to send"),
    messageType: z.enum(["reminder", "escalation", "update"]).optional().describe("Type of message being sent")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    messageId: z.string(),
    sentTo: z.string(),
    sentAt: z.string()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F4AC} [Teams Message Tool] Starting execution", {
      userEmail: context.userEmail,
      messageType: context.messageType
    });
    logger?.info("\u{1F4DD} [Teams Message Tool] Using mock implementation for development");
    logger?.info("\u{1F4AD} [Teams Message Tool] Message details:", {
      userEmail: context.userEmail,
      messageType: context.messageType || "update",
      messagePreview: context.message.substring(0, 100) + "..."
    });
    const messageId = `mock-teams-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const sentAt = (/* @__PURE__ */ new Date()).toISOString();
    logger?.info("\u2705 [Teams Message Tool] Message sent successfully", {
      messageId,
      sentTo: context.userEmail,
      sentAt
    });
    return {
      success: true,
      messageId,
      sentTo: context.userEmail,
      sentAt
    };
  }
});

const taskLog = [];
const taskLoggerTool = createTool({
  id: "task-logger",
  description: "Logs reminder and escalation activities for audit trail and tracking reminder counts",
  inputSchema: z.object({
    taskId: z.number().describe("Azure DevOps task ID"),
    taskTitle: z.string().describe("Task title"),
    assigneeEmail: z.string().describe("Email of the person assigned to the task"),
    managerEmail: z.string().optional().describe("Email of the manager (for escalations)"),
    actionType: z.enum(["reminder", "escalation"]).describe("Type of action being logged"),
    channel: z.enum(["email", "teams"]).describe("Communication channel used"),
    messageId: z.string().describe("ID of the sent message")
  }),
  outputSchema: z.object({
    success: z.boolean(),
    logId: z.string(),
    loggedAt: z.string(),
    reminderCount: z.number().describe("Total number of reminders sent for this task")
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F4DD} [Task Logger Tool] Starting execution", {
      taskId: context.taskId,
      actionType: context.actionType
    });
    const logId = `log-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const loggedAt = (/* @__PURE__ */ new Date()).toISOString();
    const logEntry = {
      id: logId,
      taskId: context.taskId,
      taskTitle: context.taskTitle,
      assigneeEmail: context.assigneeEmail,
      managerEmail: context.managerEmail,
      actionType: context.actionType,
      timestamp: loggedAt,
      messageDetails: {
        channel: context.channel,
        messageId: context.messageId
      }
    };
    taskLog.push(logEntry);
    const reminderCount = taskLog.filter(
      (log) => log.taskId === context.taskId && log.actionType === "reminder"
    ).length;
    logger?.info("\u{1F4BE} [Task Logger Tool] Log entry created", {
      logId,
      taskId: context.taskId,
      actionType: context.actionType,
      reminderCount,
      totalLogs: taskLog.length
    });
    logger?.info("\u2705 [Task Logger Tool] Completed successfully", {
      logId,
      reminderCount
    });
    return {
      success: true,
      logId,
      loggedAt,
      reminderCount
    };
  }
});
const getTaskReminderCountTool = createTool({
  id: "get-task-reminder-count",
  description: "Gets the number of reminders sent for a specific task to determine if escalation is needed",
  inputSchema: z.object({
    taskId: z.number().describe("Azure DevOps task ID")
  }),
  outputSchema: z.object({
    taskId: z.number(),
    reminderCount: z.number(),
    lastReminderAt: z.string().optional(),
    hasEscalated: z.boolean()
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F50D} [Get Reminder Count Tool] Checking reminder count", {
      taskId: context.taskId
    });
    const reminders = taskLog.filter(
      (log) => log.taskId === context.taskId && log.actionType === "reminder"
    );
    const escalations = taskLog.filter(
      (log) => log.taskId === context.taskId && log.actionType === "escalation"
    );
    const lastReminder = reminders.length > 0 ? reminders[reminders.length - 1].timestamp : void 0;
    logger?.info("\u2705 [Get Reminder Count Tool] Query completed", {
      taskId: context.taskId,
      reminderCount: reminders.length,
      hasEscalated: escalations.length > 0
    });
    return {
      taskId: context.taskId,
      reminderCount: reminders.length,
      lastReminderAt: lastReminder,
      hasEscalated: escalations.length > 0
    };
  }
});

const sprintMetricsTool = createTool({
  id: "sprint-metrics-analyzer",
  description: "Analyzes sprint health metrics including velocity, burndown, and team capacity",
  inputSchema: z.object({
    tasks: z.array(z.object({
      id: z.number(),
      storyPoints: z.number(),
      state: z.string(),
      priority: z.string(),
      blockedBy: z.number().nullable(),
      lastUpdated: z.string()
    })),
    sprintContext: z.object({
      id: z.string(),
      totalStoryPoints: z.number(),
      completedStoryPoints: z.number(),
      daysRemaining: z.number()
    })
  }),
  outputSchema: z.object({
    summary: z.string(),
    risksIdentified: z.array(z.object({
      type: z.string(),
      severity: z.enum(["low", "medium", "high", "critical"]),
      description: z.string(),
      recommendation: z.string()
    })),
    metrics: z.object({
      totalActiveTasks: z.number(),
      blockedTasks: z.number(),
      staleTasks: z.number(),
      averageStoryPoints: z.number(),
      velocityProjection: z.number(),
      sprintCompletionProbability: z.number()
    })
  }),
  execute: async ({ context, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F4CA} [Sprint Metrics Tool] Analyzing sprint health...");
    const { tasks, sprintContext } = context;
    const now = /* @__PURE__ */ new Date();
    const activeTasks = tasks.filter((t) => t.state === "Active");
    const blockedTasks = tasks.filter((t) => t.blockedBy !== null);
    const staleTasks = tasks.filter((t) => {
      const hoursSinceUpdate = (now.getTime() - new Date(t.lastUpdated).getTime()) / (1e3 * 60 * 60);
      return hoursSinceUpdate > 48;
    });
    const activeStoryPoints = activeTasks.reduce((sum, t) => sum + t.storyPoints, 0);
    const averageStoryPoints = activeStoryPoints / (activeTasks.length || 1);
    const daysElapsed = 14 - sprintContext.daysRemaining;
    const currentVelocity = daysElapsed > 0 ? sprintContext.completedStoryPoints / daysElapsed : 0;
    const velocityProjection = currentVelocity * sprintContext.daysRemaining + sprintContext.completedStoryPoints;
    const sprintCompletionProbability = Math.min(100, velocityProjection / sprintContext.totalStoryPoints * 100);
    const risks = [];
    if (blockedTasks.length > 0) {
      risks.push({
        type: "BLOCKED_TASKS",
        severity: blockedTasks.length > 2 ? "high" : "medium",
        description: `${blockedTasks.length} task(s) are blocked by dependencies`,
        recommendation: "Hold dependency resolution meeting with team leads"
      });
    }
    if (staleTasks.length > 2) {
      risks.push({
        type: "STALE_TASKS",
        severity: "high",
        description: `${staleTasks.length} tasks haven't been updated in over 48 hours`,
        recommendation: "Immediate check-in required with assignees during daily standup"
      });
    }
    if (sprintCompletionProbability < 70) {
      risks.push({
        type: "VELOCITY_RISK",
        severity: "critical",
        description: `Only ${sprintCompletionProbability.toFixed(0)}% probability of completing sprint`,
        recommendation: "Consider descoping lower priority items or extending sprint capacity"
      });
    }
    if (sprintContext.daysRemaining < 3 && activeStoryPoints > 10) {
      risks.push({
        type: "SPRINT_CRUNCH",
        severity: "high",
        description: `${activeStoryPoints} story points remaining with only ${sprintContext.daysRemaining} days left`,
        recommendation: "Prioritize critical items and move non-essential tasks to next sprint"
      });
    }
    const summary = `
Sprint ${sprintContext.id} Health Report:
- Active Tasks: ${activeTasks.length}
- Blocked: ${blockedTasks.length}
- Stale (>48hrs): ${staleTasks.length}
- Completion Probability: ${sprintCompletionProbability.toFixed(0)}%
- Risks Identified: ${risks.length}
`;
    logger?.info("\u2705 [Sprint Metrics Tool] Analysis complete", {
      risksCount: risks.length,
      completionProbability: sprintCompletionProbability
    });
    return {
      summary,
      risksIdentified: risks,
      metrics: {
        totalActiveTasks: activeTasks.length,
        blockedTasks: blockedTasks.length,
        staleTasks: staleTasks.length,
        averageStoryPoints,
        velocityProjection,
        sprintCompletionProbability
      }
    };
  }
});

const INACTIVE_HOURS_THRESHOLD = parseInt(process.env.INACTIVE_HOURS_THRESHOLD || "48");
const REMINDER_COUNT_THRESHOLD = parseInt(process.env.REMINDER_COUNT_THRESHOLD || "2");
const COMMUNICATION_CHANNEL = process.env.COMMUNICATION_CHANNEL || "email";
const runtimeContext = new RuntimeContext();
const fetchActiveTasks = createStep({
  id: "fetch-active-tasks",
  description: "Fetches all active tasks from Azure DevOps",
  inputSchema: z.object({}).passthrough(),
  outputSchema: z.object({
    tasks: z.array(z.object({
      id: z.number(),
      title: z.string(),
      assignedTo: z.object({
        displayName: z.string(),
        email: z.string(),
        managerId: z.string()
      }),
      state: z.string(),
      priority: z.string(),
      lastUpdated: z.string(),
      createdDate: z.string(),
      url: z.string(),
      storyPoints: z.number(),
      sprintId: z.string(),
      blockedBy: z.number().nullable(),
      tags: z.array(z.string()),
      manager: z.object({
        displayName: z.string(),
        email: z.string()
      }).optional()
    })),
    totalCount: z.number(),
    sprintContext: z.object({
      id: z.string(),
      startDate: z.string(),
      endDate: z.string(),
      totalStoryPoints: z.number(),
      completedStoryPoints: z.number(),
      daysRemaining: z.number(),
      velocityOnTrack: z.boolean()
    })
  }),
  execute: async ({ mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F680} [Step 1] Fetching active tasks from Azure DevOps...");
    const result = await azureDevOpsTool.execute({
      context: { state: "Active" },
      runtimeContext
    });
    logger?.info("\u2705 [Step 1] Fetched tasks", {
      totalCount: result.totalCount,
      taskIds: result.tasks.map((t) => t.id)
    });
    return result;
  }
});
const analyzeSprintHealth = createStep({
  id: "analyze-sprint-health",
  description: "Analyzes sprint metrics and identifies risks",
  inputSchema: z.object({
    tasks: z.array(z.object({
      id: z.number(),
      title: z.string(),
      assignedTo: z.object({
        displayName: z.string(),
        email: z.string(),
        managerId: z.string()
      }),
      state: z.string(),
      priority: z.string(),
      lastUpdated: z.string(),
      createdDate: z.string(),
      url: z.string(),
      storyPoints: z.number(),
      sprintId: z.string(),
      blockedBy: z.number().nullable(),
      tags: z.array(z.string()),
      manager: z.object({
        displayName: z.string(),
        email: z.string()
      }).optional()
    })),
    totalCount: z.number(),
    sprintContext: z.object({
      id: z.string(),
      startDate: z.string(),
      endDate: z.string(),
      totalStoryPoints: z.number(),
      completedStoryPoints: z.number(),
      daysRemaining: z.number(),
      velocityOnTrack: z.boolean()
    })
  }),
  outputSchema: z.object({
    tasks: z.array(z.any()),
    totalCount: z.number(),
    sprintContext: z.any(),
    sprintAnalysis: z.object({
      summary: z.string(),
      risksIdentified: z.array(z.object({
        type: z.string(),
        severity: z.enum(["low", "medium", "high", "critical"]),
        description: z.string(),
        recommendation: z.string()
      })),
      metrics: z.object({
        totalActiveTasks: z.number(),
        blockedTasks: z.number(),
        staleTasks: z.number(),
        averageStoryPoints: z.number(),
        velocityProjection: z.number(),
        sprintCompletionProbability: z.number()
      })
    })
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F4CA} [Step 2] Analyzing sprint health...");
    const analysis = await sprintMetricsTool.execute({
      context: {
        tasks: inputData.tasks.map((t) => ({
          id: t.id,
          storyPoints: t.storyPoints,
          state: t.state,
          priority: t.priority,
          blockedBy: t.blockedBy,
          lastUpdated: t.lastUpdated
        })),
        sprintContext: inputData.sprintContext
      },
      runtimeContext: new RuntimeContext()
    });
    logger?.info("\u2705 [Step 2] Sprint analysis complete", {
      risksCount: analysis.risksIdentified.length,
      completionProbability: analysis.metrics.sprintCompletionProbability
    });
    return {
      tasks: inputData.tasks,
      totalCount: inputData.totalCount,
      sprintContext: inputData.sprintContext,
      sprintAnalysis: analysis
    };
  }
});
const processInactiveTasks = createStep({
  id: "process-inactive-tasks",
  description: "Identifies inactive tasks and sends reminders or escalations",
  inputSchema: z.object({
    tasks: z.array(z.any()),
    totalCount: z.number(),
    sprintContext: z.any(),
    sprintAnalysis: z.object({
      summary: z.string(),
      risksIdentified: z.array(z.any()),
      metrics: z.any()
    })
  }),
  outputSchema: z.object({
    processed: z.number(),
    reminders: z.number(),
    escalations: z.number(),
    skipped: z.number(),
    fieldReminders: z.number(),
    details: z.array(z.object({
      taskId: z.number(),
      taskTitle: z.string(),
      action: z.enum(["reminder", "escalation", "skipped", "field_reminder"]),
      reason: z.string()
    }))
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F50D} [Step 3] Processing tasks for inactivity and missing fields...");
    const details = [];
    let remindersSent = 0;
    let escalationsSent = 0;
    let skipped = 0;
    let fieldRemindersSent = 0;
    const requiredFields = ["storyPoints", "priority"];
    for (const task of inputData.tasks) {
      logger?.info(`\u{1F4CB} [Step 3] Analyzing task ${task.id}: ${task.title}`);
      const missingFields = requiredFields.filter((field) => task[field] === null || task[field] === void 0 || task[field] === "");
      if (missingFields.length > 0) {
        logger?.info(`\u26A0\uFE0F  [Step 3] Task ${task.id} is missing fields: ${missingFields.join(", ")}`);
        const fieldReminderMessage = `
Hi ${task.assignedTo.displayName},

This is a reminder that your task in Azure DevOps is missing some required fields:
${missingFields.map((field) => `- ${field}`).join("\n")}

Please update these fields as soon as possible to ensure accurate tracking and reporting.

Task URL: ${task.url}

Best regards,
Your Scrum Automation Bot
        `;
        let messageId;
        if (COMMUNICATION_CHANNEL === "teams") {
          const teamsResult = await teamsMessageTool.execute({
            context: {
              userEmail: task.assignedTo.email,
              message: fieldReminderMessage,
              messageType: "field_reminder"
            },
            runtimeContext
          });
          messageId = teamsResult.messageId;
          logger?.info(`\u{1F4AC} [Step 3] Sent Teams field reminder to ${task.assignedTo.email} for task ${task.id}`);
        } else {
          const emailResult = await outlookEmailTool.execute({
            context: {
              to: task.assignedTo.email,
              subject: `Action Required: Missing Fields in Task #${task.id} - ${task.title}`,
              body: fieldReminderMessage,
              importance: "high"
            },
            runtimeContext
          });
          messageId = emailResult.messageId;
          logger?.info(`\u{1F4E7} [Step 3] Sent email field reminder to ${task.assignedTo.email} for task ${task.id}`);
        }
        await taskLoggerTool.execute({
          context: {
            taskId: task.id,
            taskTitle: task.title,
            assigneeEmail: task.assignedTo.email,
            actionType: "field_reminder",
            channel: COMMUNICATION_CHANNEL,
            messageId
          },
          runtimeContext
        });
        fieldRemindersSent++;
        details.push({
          taskId: task.id,
          taskTitle: task.title,
          action: "field_reminder",
          reason: `Missing fields: ${missingFields.join(", ")}`
        });
        continue;
      }
      const lastUpdated = new Date(task.lastUpdated);
      const now = /* @__PURE__ */ new Date();
      const hoursSinceUpdate = (now.getTime() - lastUpdated.getTime()) / (1e3 * 60 * 60);
      logger?.info(`\u23F0 [Step 3] Task ${task.id} last updated ${hoursSinceUpdate.toFixed(1)} hours ago`);
      if (hoursSinceUpdate < INACTIVE_HOURS_THRESHOLD) {
        logger?.info(`\u2713 [Step 3] Task ${task.id} is active, skipping inactivity check`);
        skipped++;
        details.push({
          taskId: task.id,
          taskTitle: task.title,
          action: "skipped",
          reason: `Task is active (updated ${hoursSinceUpdate.toFixed(1)} hours ago)`
        });
        continue;
      }
      logger?.info(`\u26A0\uFE0F  [Step 3] Task ${task.id} is INACTIVE (${hoursSinceUpdate.toFixed(1)} hours)`);
      const reminderCountResult = await getTaskReminderCountTool.execute({
        context: { taskId: task.id },
        runtimeContext
      });
      const reminderCount = reminderCountResult.reminderCount;
      const hasEscalated = reminderCountResult.hasEscalated;
      logger?.info(`\u{1F4CA} [Step 3] Task ${task.id} reminder count: ${reminderCount}, escalated: ${hasEscalated}`);
      if (hasEscalated) {
        logger?.info(`\u23ED\uFE0F  [Step 3] Task ${task.id} already escalated, skipping`);
        skipped++;
        details.push({
          taskId: task.id,
          taskTitle: task.title,
          action: "skipped",
          reason: "Already escalated to manager"
        });
        continue;
      }
      if (reminderCount < REMINDER_COUNT_THRESHOLD) {
        logger?.info(`\u{1F4EC} [Step 3] Sending reminder ${reminderCount + 1} for task ${task.id}`);
        const isBlocked = task.blockedBy !== null;
        const blockedWarning = isBlocked ? `
\u26A0\uFE0F **NOTE**: This task is blocked by Task #${task.blockedBy}. Please coordinate with the team to resolve the dependency.
` : "";
        const reminderMessage = `
Hi ${task.assignedTo.displayName},

This is a friendly reminder about your task in Azure DevOps:

**Task #${task.id}: ${task.title}**
Priority: ${task.priority}
Story Points: ${task.storyPoints}
Sprint: ${inputData.sprintContext.id} (${inputData.sprintContext.daysRemaining} days remaining)
Last Updated: ${Math.floor(hoursSinceUpdate)} hours ago
${blockedWarning}
**Sprint Context:**
- Sprint Completion Probability: ${inputData.sprintAnalysis.metrics.sprintCompletionProbability.toFixed(0)}%
- Your task represents ${(task.storyPoints / inputData.sprintContext.totalStoryPoints * 100).toFixed(0)}% of sprint capacity

This task hasn't been updated in a while. When you get a chance, could you please:
- Review the current status
- Update the task with any progress or blockers
- Move it forward if possible
${isBlocked ? "- Coordinate with dependencies to unblock this task" : ""}

You can access the task here: ${task.url}

This is reminder #${reminderCount + 1}. If you need any support or have questions, please don't hesitate to reach out to your team lead.

Best regards,
Your Scrum Automation Bot
        `;
        logger?.info(`\u270D\uFE0F  [Step 3] Composed reminder message for task ${task.id}`);
        let messageId;
        if (COMMUNICATION_CHANNEL === "teams") {
          const teamsResult = await teamsMessageTool.execute({
            context: {
              userEmail: task.assignedTo.email,
              message: reminderMessage,
              messageType: "reminder"
            },
            runtimeContext
          });
          messageId = teamsResult.messageId;
          logger?.info(`\u{1F4AC} [Step 3] Sent Teams reminder to ${task.assignedTo.email}`);
        } else {
          const emailResult = await outlookEmailTool.execute({
            context: {
              to: task.assignedTo.email,
              subject: `Reminder: Task #${task.id} - ${task.title}`,
              body: reminderMessage,
              importance: task.priority === "Critical" ? "high" : "normal"
            },
            runtimeContext
          });
          messageId = emailResult.messageId;
          logger?.info(`\u{1F4E7} [Step 3] Sent email reminder to ${task.assignedTo.email}`);
        }
        await taskLoggerTool.execute({
          context: {
            taskId: task.id,
            taskTitle: task.title,
            assigneeEmail: task.assignedTo.email,
            actionType: "reminder",
            channel: COMMUNICATION_CHANNEL,
            messageId
          },
          runtimeContext
        });
        remindersSent++;
        details.push({
          taskId: task.id,
          taskTitle: task.title,
          action: "reminder",
          reason: `Sent reminder #${reminderCount + 1} (inactive for ${Math.floor(hoursSinceUpdate)} hours)`
        });
      } else {
        logger?.info(`\u{1F6A8} [Step 3] Escalating task ${task.id} to manager after ${reminderCount} reminders`);
        if (!task.manager) {
          logger?.warn(`\u26A0\uFE0F  [Step 3] No manager found for task ${task.id}, skipping escalation`);
          skipped++;
          details.push({
            taskId: task.id,
            taskTitle: task.title,
            action: "skipped",
            reason: "Manager information not available"
          });
          continue;
        }
        const escalationMessage = `
Hi ${task.manager.displayName},

I'm reaching out regarding a task that requires your attention:

**Task #${task.id}: ${task.title}**
Assigned to: ${task.assignedTo.displayName} (${task.assignedTo.email})
Priority: ${task.priority}
Last Updated: ${Math.floor(hoursSinceUpdate)} hours ago
Reminders Sent: ${reminderCount}

**Situation Summary:**
This ${task.priority.toLowerCase()} priority task has been inactive for ${Math.floor(hoursSinceUpdate / 24)} days. We've sent ${reminderCount} automated reminders to ${task.assignedTo.displayName}, but the task hasn't been updated.

**Recommended Actions:**
- Check in with ${task.assignedTo.displayName} to understand any blockers
- Assess if additional resources or support are needed
- Determine if the task priority or assignment needs adjustment

You can view the full task details here: ${task.url}

Please let me know if you need any additional information.

Best regards,
Your Scrum Automation System
        `;
        logger?.info(`\u270D\uFE0F  [Step 3] Composed escalation message for task ${task.id}`);
        let messageId;
        if (COMMUNICATION_CHANNEL === "teams") {
          const teamsResult = await teamsMessageTool.execute({
            context: {
              userEmail: task.manager.email,
              message: escalationMessage,
              messageType: "escalation"
            },
            runtimeContext
          });
          messageId = teamsResult.messageId;
          logger?.info(`\u{1F4AC} [Step 3] Sent Teams escalation to ${task.manager.email}`);
        } else {
          const emailResult = await outlookEmailTool.execute({
            context: {
              to: task.manager.email,
              subject: `Escalation: Task #${task.id} - ${task.title}`,
              body: escalationMessage,
              cc: task.assignedTo.email,
              importance: "high"
            },
            runtimeContext
          });
          messageId = emailResult.messageId;
          logger?.info(`\u{1F4E7} [Step 3] Sent email escalation to ${task.manager.email}`);
        }
        await taskLoggerTool.execute({
          context: {
            taskId: task.id,
            taskTitle: task.title,
            assigneeEmail: task.assignedTo.email,
            managerEmail: task.manager.email,
            actionType: "escalation",
            channel: COMMUNICATION_CHANNEL,
            messageId
          },
          runtimeContext
        });
        escalationsSent++;
        details.push({
          taskId: task.id,
          taskTitle: task.title,
          action: "escalation",
          reason: `Escalated to ${task.manager.displayName} after ${reminderCount} reminders`
        });
      }
    }
    logger?.info("\u2705 [Step 3] Task processing completed", {
      processed: inputData.totalCount,
      reminders: remindersSent,
      escalations: escalationsSent,
      skipped,
      fieldReminders: fieldRemindersSent
    });
    return {
      processed: inputData.totalCount,
      reminders: remindersSent,
      escalations: escalationsSent,
      skipped,
      fieldReminders: fieldRemindersSent,
      details
    };
  }
});
const generateSummary = createStep({
  id: "generate-summary",
  description: "Generates a summary of the automation run",
  inputSchema: z.object({
    processed: z.number(),
    reminders: z.number(),
    escalations: z.number(),
    skipped: z.number(),
    fieldReminders: z.number(),
    details: z.array(z.object({
      taskId: z.number(),
      taskTitle: z.string(),
      action: z.enum(["reminder", "escalation", "skipped", "field_reminder"]),
      reason: z.string()
    }))
  }),
  outputSchema: z.object({
    summary: z.string(),
    timestamp: z.string(),
    stats: z.object({
      processed: z.number(),
      reminders: z.number(),
      fieldReminders: z.number(),
      escalations: z.number(),
      skipped: z.number()
    })
  }),
  execute: async ({ inputData, mastra }) => {
    const logger = mastra?.getLogger();
    logger?.info("\u{1F4CA} [Step 4] Generating summary report...");
    const timestamp = (/* @__PURE__ */ new Date()).toISOString();
    const summary = `
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
\u{1F4CB} SCRUM AUTOMATION SUMMARY
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Timestamp: ${timestamp}

\u{1F4C8} STATISTICS:
  \u2022 Tasks Processed: ${inputData.processed}
  \u2022 Reminders Sent: ${inputData.reminders}
  \u2022 Field Reminders Sent: ${inputData.fieldReminders}
  \u2022 Escalations Sent: ${inputData.escalations}
  \u2022 Tasks Skipped: ${inputData.skipped}

\u{1F4CB} DETAILS:
${inputData.details.map((d) => `  \u2022 Task #${d.taskId} (${d.action}): ${d.reason}`).join("\n")}

\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
`;
    logger?.info(summary);
    logger?.info("\u2705 [Step 4] Summary report generated");
    return {
      summary,
      timestamp,
      stats: {
        processed: inputData.processed,
        reminders: inputData.reminders,
        fieldReminders: inputData.fieldReminders,
        escalations: inputData.escalations,
        skipped: inputData.skipped
      }
    };
  }
});
const scrumAutomationWorkflow = createWorkflow({
  id: "scrum-automation",
  description: "Monitors Azure DevOps tasks, analyzes sprint health, sends reminders, and escalates inactive tasks to managers. Also sends reminders for missing fields.",
  inputSchema: z.object({}),
  outputSchema: z.object({
    summary: z.string(),
    timestamp: z.string(),
    stats: z.object({
      processed: z.number(),
      reminders: z.number(),
      fieldReminders: z.number(),
      escalations: z.number(),
      skipped: z.number()
    })
  })
}).then(fetchActiveTasks).then(analyzeSprintHealth).then(processInactiveTasks).then(generateSummary).commit();

class ProductionPinoLogger extends MastraLogger {
  logger;
  constructor(options = {}) {
    super(options);
    this.logger = pino({
      name: options.name || "app",
      level: options.level || LogLevel.INFO,
      base: {},
      formatters: {
        level: (label, _number) => ({
          level: label
        })
      },
      timestamp: () => `,"time":"${new Date(Date.now()).toISOString()}"`
    });
  }
  debug(message, args = {}) {
    this.logger.debug(args, message);
  }
  info(message, args = {}) {
    this.logger.info(args, message);
  }
  warn(message, args = {}) {
    this.logger.warn(args, message);
  }
  error(message, args = {}) {
    this.logger.error(args, message);
  }
}
registerCronWorkflow(`TZ=${process.env.SCHEDULE_CRON_TIMEZONE || "America/Los_Angeles"} ${process.env.SCHEDULE_CRON_EXPRESSION || "0 * * * *"}`, scrumAutomationWorkflow);
const mastra = new Mastra({
  storage: sharedPostgresStorage,
  // Register your workflows here
  workflows: {
    scrumAutomationWorkflow
  },
  // Register your agents here
  agents: {},
  mcpServers: {
    allTools: new MCPServer({
      name: "allTools",
      version: "1.0.0",
      tools: {
        azureDevOpsTool,
        outlookEmailTool,
        teamsMessageTool,
        taskLoggerTool,
        getTaskReminderCountTool
      }
    })
  },
  bundler: {
    // A few dependencies are not properly picked up by
    // the bundler if they are not added directly to the
    // entrypoint.
    externals: ["@slack/web-api", "inngest", "inngest/hono", "hono", "hono/streaming"],
    // sourcemaps are good for debugging.
    sourcemap: true
  },
  server: {
    host: "0.0.0.0",
    port: 5e3,
    onStart: async ({
      app
    }) => {
      const {
        registerDashboardRoutes
      } = await Promise.resolve().then(function () { return dashboardRoutes; });
      registerDashboardRoutes(app);
    },
    middleware: [async (c, next) => {
      const mastra2 = c.get("mastra");
      const logger = mastra2?.getLogger();
      logger?.debug("[Request]", {
        method: c.req.method,
        url: c.req.url
      });
      try {
        await next();
      } catch (error) {
        logger?.error("[Response]", {
          method: c.req.method,
          url: c.req.url,
          error
        });
        if (error instanceof MastraError) {
          if (error.id === "AGENT_MEMORY_MISSING_RESOURCE_ID") {
            throw new NonRetriableError(error.message, {
              cause: error
            });
          }
        } else if (error instanceof z.ZodError) {
          throw new NonRetriableError(error.message, {
            cause: error
          });
        }
        throw error;
      }
    }],
    apiRoutes: [
      // This API route is used to register the Mastra workflow (inngest function) on the inngest server
      {
        path: "/api/inngest",
        method: "ALL",
        createHandler: async ({
          mastra: mastra2
        }) => inngestServe({
          mastra: mastra2,
          inngest
        })
        // The inngestServe function integrates Mastra workflows with Inngest by:
        // 1. Creating Inngest functions for each workflow with unique IDs (workflow.${workflowId})
        // 2. Setting up event handlers that:
        //    - Generate unique run IDs for each workflow execution
        //    - Create an InngestExecutionEngine to manage step execution
        //    - Handle workflow state persistence and real-time updates
        // 3. Establishing a publish-subscribe system for real-time monitoring
        //    through the workflow:${workflowId}:${runId} channel
      }
    ]
  },
  logger: process.env.NODE_ENV === "production" ? new ProductionPinoLogger({
    name: "Mastra",
    level: "info"
  }) : new PinoLogger({
    name: "Mastra",
    level: "info"
  })
});
if (Object.keys(mastra.getWorkflows()).length > 1) {
  throw new Error("More than 1 workflows found. Currently, more than 1 workflows are not supported in the UI, since doing so will cause app state to be inconsistent.");
}
if (Object.keys(mastra.getAgents()).length > 1) {
  throw new Error("More than 1 agents found. Currently, more than 1 agents are not supported in the UI, since doing so will cause app state to be inconsistent.");
}

function registerDashboardRoutes(app) {
  app.get("/dashboard", async (c) => {
    const html = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scrum Automation Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .metric-card { transition: all 0.3s ease; }
        .metric-card:hover { transform: translateY(-4px); box-shadow: 0 12px 24px rgba(0,0,0,0.1); }
        .status-indicator { width: 12px; height: 12px; border-radius: 50%; display: inline-block; margin-right: 8px; }
        .status-healthy { background-color: #10b981; }
        .status-warning { background-color: #f59e0b; }
        .status-critical { background-color: #ef4444; }
    </style>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="bg-white shadow-sm border-b border-gray-200">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
                <div class="flex justify-between items-center">
                    <div>
                        <h1 class="text-2xl font-bold text-gray-900">Scrum Automation Dashboard</h1>
                        <p class="text-sm text-gray-500 mt-1">Real-time monitoring and analytics</p>
                    </div>
                    <div class="flex gap-3">
                        <button onclick="runWorkflow()" 
                                class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                            \u25B6 Run Workflow Now
                        </button>
                        <button onclick="refreshDashboard()" 
                                class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition">
                            \u{1F504} Refresh
                        </button>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <!-- Loading State -->
            <div id="loading" class="text-center py-12">
                <div class="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                <p class="mt-4 text-gray-600">Loading dashboard data...</p>
            </div>

            <!-- Dashboard Content (hidden initially) -->
            <div id="dashboard-content" class="hidden">
                <!-- Overview Metrics -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
                    <div class="metric-card bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                        <div class="text-sm font-medium text-gray-500 mb-2">Active Tasks</div>
                        <div class="text-3xl font-bold text-gray-900" id="metric-active-tasks">-</div>
                    </div>
                    <div class="metric-card bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                        <div class="text-sm font-medium text-gray-500 mb-2">Missing Fields</div>
                        <div class="text-3xl font-bold text-orange-600" id="metric-missing-fields">-</div>
                    </div>
                    <div class="metric-card bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                        <div class="text-sm font-medium text-gray-500 mb-2">Inactive Tasks</div>
                        <div class="text-3xl font-bold text-red-600" id="metric-inactive-tasks">-</div>
                    </div>
                    <div class="metric-card bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                        <div class="text-sm font-medium text-gray-500 mb-2">Recent Reminders</div>
                        <div class="text-3xl font-bold text-blue-600" id="metric-reminders">-</div>
                    </div>
                    <div class="metric-card bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                        <div class="text-sm font-medium text-gray-500 mb-2">Escalations</div>
                        <div class="text-3xl font-bold text-purple-600" id="metric-escalations">-</div>
                    </div>
                </div>

                <!-- Sprint Health -->
                <div class="bg-white rounded-lg shadow-sm p-6 mb-8 border border-gray-200">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">Sprint Health</h2>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div>
                            <div class="flex items-center mb-2">
                                <span id="health-indicator" class="status-indicator status-healthy"></span>
                                <span class="text-sm font-medium text-gray-500">Sprint: <span id="sprint-id">-</span></span>
                            </div>
                            <div class="text-4xl font-bold text-gray-900 mb-1" id="completion-probability">-</div>
                            <div class="text-sm text-gray-500">Completion Probability</div>
                        </div>
                        <div>
                            <div class="text-sm font-medium text-gray-500 mb-2">Days Remaining</div>
                            <div class="text-4xl font-bold text-gray-900" id="days-remaining">-</div>
                        </div>
                        <div>
                            <div class="text-sm font-medium text-gray-500 mb-2">Velocity Projection</div>
                            <div class="text-4xl font-bold text-gray-900" id="velocity-projection">-</div>
                            <div class="text-sm text-gray-500">story points</div>
                        </div>
                    </div>
                    <div class="mt-6 grid grid-cols-3 gap-4">
                        <div class="text-center p-4 bg-red-50 rounded-lg">
                            <div class="text-2xl font-bold text-red-600" id="blocked-tasks">-</div>
                            <div class="text-sm text-gray-600">Blocked Tasks</div>
                        </div>
                        <div class="text-center p-4 bg-yellow-50 rounded-lg">
                            <div class="text-2xl font-bold text-yellow-600" id="stale-tasks">-</div>
                            <div class="text-sm text-gray-600">Stale Tasks</div>
                        </div>
                        <div class="text-center p-4 bg-orange-50 rounded-lg">
                            <div class="text-2xl font-bold text-orange-600" id="risks-count">-</div>
                            <div class="text-sm text-gray-600">Identified Risks</div>
                        </div>
                    </div>
                </div>

                <!-- Analytics Charts -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                    <div class="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Tasks by Priority</h3>
                        <canvas id="priority-chart"></canvas>
                    </div>
                    <div class="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-900 mb-4">Missing Fields Breakdown</h3>
                        <canvas id="fields-chart"></canvas>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="bg-white rounded-lg shadow-sm p-6 mb-8 border border-gray-200">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">Recent Activity</h2>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead>
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Task</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Assignee</th>
                                </tr>
                            </thead>
                            <tbody id="activity-table" class="divide-y divide-gray-200">
                                <!-- Populated by JavaScript -->
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Workflow History -->
                <div class="bg-white rounded-lg shadow-sm p-6 border border-gray-200">
                    <h2 class="text-xl font-bold text-gray-900 mb-4">Workflow Execution History</h2>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead>
                                <tr>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Run ID</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Time</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Processed</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Reminders</th>
                                    <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Escalations</th>
                                </tr>
                            </thead>
                            <tbody id="workflow-table" class="divide-y divide-gray-200">
                                <!-- Populated by JavaScript -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        let priorityChart, fieldsChart;

        async function loadDashboard() {
            try {
                const response = await fetch('/api/dashboard/metrics');
                const data = await response.json();
                
                updateMetrics(data);
                updateCharts(data);
                updateActivityTable(data.recentActivity);
                updateWorkflowTable(data.workflowHistory);
                
                document.getElementById('loading').classList.add('hidden');
                document.getElementById('dashboard-content').classList.remove('hidden');
            } catch (error) {
                console.error('Error loading dashboard:', error);
                document.getElementById('loading').innerHTML = '<p class="text-red-600">Error loading dashboard. Please try again.</p>';
            }
        }

        function updateMetrics(data) {
            document.getElementById('metric-active-tasks').textContent = data.overview.totalActiveTasks;
            document.getElementById('metric-missing-fields').textContent = data.overview.tasksWithMissingFields;
            document.getElementById('metric-inactive-tasks').textContent = data.overview.inactiveTasks;
            document.getElementById('metric-reminders').textContent = data.overview.recentReminders;
            document.getElementById('metric-escalations').textContent = data.overview.recentEscalations;
            
            document.getElementById('sprint-id').textContent = data.sprintHealth.sprintId;
            document.getElementById('completion-probability').textContent = Math.round(data.sprintHealth.completionProbability) + '%';
            document.getElementById('days-remaining').textContent = data.sprintHealth.daysRemaining;
            document.getElementById('velocity-projection').textContent = Math.round(data.sprintHealth.velocityProjection);
            document.getElementById('blocked-tasks').textContent = data.sprintHealth.blockedTasks;
            document.getElementById('stale-tasks').textContent = data.sprintHealth.staleTasks;
            document.getElementById('risks-count').textContent = data.sprintHealth.risksCount;
            
            const indicator = document.getElementById('health-indicator');
            if (data.sprintHealth.completionProbability >= 80) {
                indicator.className = 'status-indicator status-healthy';
            } else if (data.sprintHealth.completionProbability >= 60) {
                indicator.className = 'status-indicator status-warning';
            } else {
                indicator.className = 'status-indicator status-critical';
            }
        }

        function updateCharts(data) {
            const priorityCtx = document.getElementById('priority-chart').getContext('2d');
            const fieldsCtx = document.getElementById('fields-chart').getContext('2d');
            
            if (priorityChart) priorityChart.destroy();
            if (fieldsChart) fieldsChart.destroy();
            
            priorityChart = new Chart(priorityCtx, {
                type: 'doughnut',
                data: {
                    labels: Object.keys(data.taskAnalytics.byPriority),
                    datasets: [{
                        data: Object.values(data.taskAnalytics.byPriority),
                        backgroundColor: ['#ef4444', '#f59e0b', '#3b82f6', '#10b981']
                    }]
                },
                options: { responsive: true, maintainAspectRatio: true }
            });
            
            fieldsChart = new Chart(fieldsCtx, {
                type: 'bar',
                data: {
                    labels: Object.keys(data.taskAnalytics.missingFieldsBreakdown),
                    datasets: [{
                        label: 'Missing Count',
                        data: Object.values(data.taskAnalytics.missingFieldsBreakdown),
                        backgroundColor: '#f59e0b'
                    }]
                },
                options: { responsive: true, maintainAspectRatio: true, scales: { y: { beginAtZero: true } } }
            });
        }

        function updateActivityTable(activities) {
            const tbody = document.getElementById('activity-table');
            tbody.innerHTML = activities.map(activity => {
                const badge = activity.type === 'escalation' ? 'bg-red-100 text-red-800' : 
                             activity.type === 'field_reminder' ? 'bg-orange-100 text-orange-800' : 
                             'bg-blue-100 text-blue-800';
                return \`
                    <tr>
                        <td class="px-4 py-3 text-sm text-gray-900">\${new Date(activity.timestamp).toLocaleString()}</td>
                        <td class="px-4 py-3 text-sm"><span class="px-2 py-1 rounded-full text-xs \${badge}">\${activity.type}</span></td>
                        <td class="px-4 py-3 text-sm text-gray-900">#\${activity.taskId}: \${activity.taskTitle}</td>
                        <td class="px-4 py-3 text-sm text-gray-600">\${activity.assignee}</td>
                    </tr>
                \`;
            }).join('');
        }

        function updateWorkflowTable(history) {
            const tbody = document.getElementById('workflow-table');
            tbody.innerHTML = history.map(run => \`
                <tr>
                    <td class="px-4 py-3 text-sm font-mono text-gray-900">\${run.runId.substring(0, 8)}...</td>
                    <td class="px-4 py-3 text-sm text-gray-900">\${new Date(run.timestamp).toLocaleString()}</td>
                    <td class="px-4 py-3 text-sm"><span class="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">\${run.status}</span></td>
                    <td class="px-4 py-3 text-sm text-gray-900">\${run.processed}</td>
                    <td class="px-4 py-3 text-sm text-gray-900">\${run.reminders}</td>
                    <td class="px-4 py-3 text-sm text-gray-900">\${run.escalations}</td>
                </tr>
            \`).join('');
        }

        async function runWorkflow() {
            if (confirm('Run the scrum automation workflow now?')) {
                document.getElementById('loading').classList.remove('hidden');
                document.getElementById('dashboard-content').classList.add('hidden');
                
                try {
                    await fetch('/api/dashboard/run-workflow', { method: 'POST' });
                    setTimeout(loadDashboard, 3000);
                } catch (error) {
                    alert('Error running workflow: ' + error.message);
                    loadDashboard();
                }
            }
        }

        function refreshDashboard() {
            document.getElementById('loading').classList.remove('hidden');
            document.getElementById('dashboard-content').classList.add('hidden');
            loadDashboard();
        }

        loadDashboard();
        setInterval(loadDashboard, 30000); // Auto-refresh every 30 seconds
    </script>
</body>
</html>
    `;
    return c.html(html);
  });
  app.get("/api/dashboard/metrics", async (c) => {
    const metrics = {
      overview: {
        totalActiveTasks: 0,
        tasksWithMissingFields: 0,
        inactiveTasks: 0,
        recentReminders: 0,
        recentEscalations: 0
      },
      sprintHealth: {
        sprintId: "Loading...",
        completionProbability: 0,
        velocityProjection: 0,
        blockedTasks: 0,
        staleTasks: 0,
        daysRemaining: 0,
        risksCount: 0
      },
      taskAnalytics: {
        byPriority: {},
        byState: {},
        missingFieldsBreakdown: {}
      },
      recentActivity: [],
      workflowHistory: []
    };
    return c.json(metrics);
  });
  app.post("/api/dashboard/run-workflow", async (c) => {
    const mastra = c.get("mastra");
    const workflow = mastra?.getWorkflow("scrumAutomationWorkflow");
    if (!workflow) {
      return c.json({ error: "Workflow not found" }, 404);
    }
    try {
      const run = await workflow.createRunAsync();
      const result = await run.start({ inputData: {} });
      return c.json({ success: true, runId: run.runId, result });
    } catch (error) {
      return c.json({ error: error.message }, 500);
    }
  });
}

var dashboardRoutes = /*#__PURE__*/Object.freeze({
  __proto__: null,
  registerDashboardRoutes: registerDashboardRoutes
});

export { mastra };
